# Aufgaben und Rechnungen

Schreib deine Aufgaben durcheinander hin und bekomm eine klare Liste. Nenn deine Rechnungen und bekomm eine Kalenderdatei, die dich rechtzeitig erinnert.

Ein kostenloses Geschenk von NOVA ONE. Kein Login, kein Abo, nichts wird irgendwohin geschickt.

---

## Installation in Claude (vier Schritte)

1. **ZIP entpacken.** Du hast einen Ordner namens `aufgaben-und-rechnungen` mit einer `SKILL.md` und dieser `README.md`.
2. **Ordner an die richtige Stelle legen.** Verschiebe den kompletten Ordner nach:

   `~/.claude/skills/aufgaben-und-rechnungen/`

   `~` ist dein Benutzerordner (Mac: `/Users/deinname`, Windows: dein Profilordner). Gibt es den Ordner `skills` noch nicht, lege ihn an. Am Ende muss die Datei `SKILL.md` direkt unter `~/.claude/skills/aufgaben-und-rechnungen/SKILL.md` liegen.
   In der Claude-App kannst du stattdessen die ZIP-Datei im Bereich "Skills" der Einstellungen hochladen.
3. **Claude neu starten**, damit die Skill geladen wird.
4. **Loslegen.** Schreib in einem Chat zum Beispiel:

   > To-Do: Zahnarzt anrufen, Steuer-Unterlagen sortieren, Geschenk für Mama, Auto-Termin
   > Rechnungen: Strom 84 € bis 15.11., Handy 29,99 € bis 20.11.

## Du nutzt ChatGPT oder Gemini?

Öffne die Datei `fuer-ChatGPT-und-Gemini.txt`, kopiere den Text und füge ihn als Anweisung ein: in ChatGPT in ein neues Projekt (Anweisungen), in Gemini in einen neuen Gem.

---

Mehr fertige Skills (insgesamt sieben) gibt es im E-Book "Dein Assistent ohne Code": novaone-group.de

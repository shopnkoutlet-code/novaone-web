# Einkaufsplaner

Sag „Plan“ und bekommst einen Wochenplan für Frühstück, Mittag und Abend plus eine Einkaufsliste, nach Supermarkt-Abteilungen sortiert.

Ein kostenloses Geschenk von NOVA ONE. Kein Login, kein Abo, nichts wird irgendwohin geschickt.

---

## Installation in Claude (vier Schritte)

1. **ZIP entpacken.** Du hast einen Ordner namens `einkaufsplaner` mit einer `SKILL.md` und dieser `README.md`.
2. **Ordner an die richtige Stelle legen.** Verschiebe den kompletten Ordner nach:

   `~/.claude/skills/einkaufsplaner/`

   `~` ist dein Benutzerordner (Mac: `/Users/deinname`, Windows: dein Profilordner). Gibt es den Ordner `skills` noch nicht, lege ihn an. Am Ende muss die Datei `SKILL.md` direkt unter `~/.claude/skills/einkaufsplaner/SKILL.md` liegen.
   In der Claude-App kannst du stattdessen die ZIP-Datei im Bereich "Skills" der Einstellungen hochladen.
3. **Claude neu starten**, damit die Skill geladen wird.
4. **Loslegen.** Schreib in einem Chat zum Beispiel:

   > Plan
   > Plan für 5 Tage
   > Ändere Tag 3
   > Ohne Fisch

## Du nutzt ChatGPT oder Gemini?

Öffne die Datei `fuer-ChatGPT-und-Gemini.txt`, kopiere den Text und füge ihn als Anweisung ein: in ChatGPT in ein neues Projekt (Anweisungen), in Gemini in einen neuen Gem.

---

Mehr fertige Skills (insgesamt sieben) gibt es im E-Book "Dein Assistent ohne Code": novaone-group.de

---
name: mein-netzwerk
description: "Baut dem Nutzer sein eigenes kleines Programm: eine lebendige Netzwerk-Ansicht mit einem Gehirn in der Mitte, seinen Lebensbereichen (zum Beispiel Haushalt, Geld, Familie, Projekte, Termine) und seinen Apps, mit Aufgabenlisten, die auf dem eigenen Gerät gespeichert werden. Entsteht als eine einzige HTML-Datei aus der mitgelieferten vorlage.html. MANDATORY TRIGGERS: 'Mein Netzwerk', 'mein Programm', 'Dashboard für mein Leben', 'Gehirn', 'Netzwerk bauen', 'Übersicht für alles'. NUR triggern, wenn der Nutzer ein persönliches Übersichts-Programm oder Dashboard will oder sein bestehendes ändert (zum Beispiel 'Füge den Bereich Sport hinzu', 'andere Farben'). NICHT triggern bei Fragen zu Webseiten, Apps für andere Menschen oder Firmenprogrammen."
---

# Mein Netzwerk

Du baust dem Nutzer ein persönliches Programm als eine einzelne HTML-Datei. Du sprichst Deutsch, einfach und freundlich.

## Erstes Gespräch
Frage einmal nach:
1. Wie soll das Programm heißen? (zum Beispiel "Mein Netzwerk")
2. Welche 4 bis 6 Lebensbereiche soll es haben? (Vorschlag: Haushalt, Geld, Familie, Projekte, Termine. Möglich ist alles Private, zum Beispiel Sport, Auto, Urlaub, Hobby.)
3. Welche Apps und Dinge nutzt der Nutzer jeden Tag? (bis 12, zum Beispiel Kalender, WhatsApp, Bank)
4. Gibt es für jeden Bereich 1 bis 3 Dinge, die gerade offen sind? (Startaufgaben)

Fasse die Antworten als Liste "Meine Daten" zusammen, die der Nutzer in seine Anweisung oder eine Notizdatei übernehmen kann. Stehen die Daten schon da, frage nicht noch einmal.

## Bauen
1. Nimm die Datei `vorlage.html` aus diesem Ordner. Kopiere sie nicht neu zusammen, sondern ändere NUR den Block zwischen "HIER ANPASSEN" und "AB HIER NICHTS ÄNDERN": `name`, `bereiche` (n = Name, f = Farbe als Hex, e = Starteinträge) und `apps`.
2. Gib dem Nutzer die fertige Datei als `mein-netzwerk.html`. Erkläre in zwei Sätzen: Datei mit Doppelklick im Browser öffnen, auf einen Bereich klicken, Einträge abhaken, hinzufügen, löschen.
3. Wenn der Nutzer keine Dateien herunterladen kann: gib den kompletten Code in einem Codeblock aus und sage, dass er ihn in eine Textdatei mit der Endung .html speichern soll.

## Änderungen
"Füge den Bereich Sport hinzu", "andere Farben", "10 Apps mehr": ändere nur den Anpassen-Block und gib die ganze Datei neu aus.

## Regeln
- Die Daten bleiben auf dem Gerät des Nutzers (Speicher des Browsers). Es wird nichts hochgeladen. Sage ihm das, wenn er fragt.
- Warne: Der Browser-Speicher geht verloren, wenn er die Browserdaten löscht. Für Wichtiges soll er eine Kopie in einer Notiz machen.
- Keine Gesundheitsdaten, Passwörter, Kontonummern oder Ausweisdaten in das Programm schreiben. Wenn der Nutzer das möchte, rate davon ab.
- Das Programm ist ein Übersichts-Werkzeug, keine Beratung.

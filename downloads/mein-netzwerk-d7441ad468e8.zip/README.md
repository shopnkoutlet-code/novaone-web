# Mein Netzwerk (Gratis-Skill von NOVA ONE)

Aus einem Gespräch mit Claude wird dein eigenes kleines Programm: ein lebendiges Netzwerk mit einem Gehirn in der Mitte, deinen Lebensbereichen (Haushalt, Geld, Familie, Projekte, Termine ...) und deinen Apps. Du klickst auf einen Bereich und siehst, was offen ist. Abhaken, ergänzen, löschen.

## So geht's (3 Schritte)
1. Lege den Ordner `mein-netzwerk` in ein Claude-Projekt oder installiere ihn als Skill (SKILL.md).
2. Schreibe: "Baue mir Mein Netzwerk."
3. Beantworte vier kurze Fragen. Du bekommst eine Datei `mein-netzwerk.html`. Doppelklick, fertig.

## Gut zu wissen
- Alles bleibt auf deinem Gerät. Nichts wird hochgeladen.
- Keine Passwörter, Kontonummern oder Gesundheitsdaten eintragen.
- Ohne Claude geht es auch: öffne `vorlage.html` in einem Texteditor und ändere die Namen oben.
- Für ChatGPT und Gemini: `fuer-ChatGPT-und-Gemini.txt`.

NOVA ONE, novaone-group.de

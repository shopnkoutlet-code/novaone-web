# Gratis-Skills: Anleitung

Du hast zwei fertige Skills für Claude bekommen: **anfrage-beantworten** und **wochenplan**. Der erste schreibt dir Antwortentwürfe auf Kundenanfragen im eigenen Ton, der zweite macht aus deiner Aufgabenliste einen Wochenplan, der in deine echte Woche passt. Beide laufen in deinem eigenen Claude-Konto, ohne Installer und ohne Programmierkenntnisse.

> Die Skills schreiben Entwürfe und Vorschläge. Sie senden nichts ab und haben keinen Zugriff auf dein Postfach. Du kopierst Nachrichten hinein und Ergebnisse heraus und prüfst alles, bevor es zum Kunden geht.

## Das brauchst du
- Ein Claude-Konto (claude.ai) mit Claude Pro oder Max (das kostenlose Claude reicht nicht), am Computer im Browser oder in der Desktop-App. Hochladen geht nur am Computer, benutzen kannst du die Skills auch auf dem Handy.
- Etwa 20 Minuten.

## In 5 Schritten startklar
1. **Entpacken.** Entpacke `gratis-skills.zip`. Du findest zwei ZIP-Dateien im Ordner `skills` und die Datei `mein-geschaeft.md`. Entpacke die beiden ZIPs nicht weiter.
2. **Code-Ausführung einschalten.** In Claude: Einstellungen, Bereich Funktionen, Schalter **Code-Ausführung und Dateierstellung** auf "an".
3. **Skills hochladen.** Einstellungen, Bereich **Skills** (bei manchen Versionen unter "Anpassen"): **Plus**, **Skill erstellen**, **Skill hochladen**. Wähle `anfrage-beantworten.zip`, danach genauso `wochenplan.zip`. Beide Schalter stehen danach auf "an".
4. **Geschäft eintragen.** Öffne `mein-geschaeft.md` in einem Texteditor und ersetze alles in [eckigen Klammern]. Für diese beiden Skills zählen die Abschnitte 1, 2, 4, 5 und 8. Die Abschnitte 3, 6 und 7 kannst du überspringen. Am meisten bewirkt Abschnitt 4 "Mein Ton": Kopiere zwei oder drei echte Nachrichten von dir hinein.
5. **Projekt anlegen.** In Claude: **Projekte**, **Neues Projekt**, Name "Mein Geschäft", die Datei `mein-geschaeft.md` im Projektwissen hinzufügen. Starte deine Chats künftig in diesem Projekt. Ohne Projekt hängst du die Datei an die erste Nachricht an.

[BILD: Skills-Seite in Claude mit den zwei hochgeladenen Skills, beide Schalter auf "an"]

## Dein erstes Ergebnis
**Anfrage beantworten.** Schreibe in einem Chat im Projekt:

```
Antworte bitte auf diese Nachricht:
"Hallo, machst du auch [deine Leistung]? Was kostet das? Lg Sandra"
```

Du bekommst "Kurz verstanden", einen "Entwurf" und, wenn nötig, einen "Hinweis für dich". Prüfe Preis und Ton, kopiere den Entwurf und sende ihn selbst ab.

**Wochenplan.** Schreibe:

```
Plan meine Woche. Aufgaben: [so durcheinander, wie sie sind].
Feste Termine: [Tag, Uhrzeit, was]. Frei bin ich: [wann].
```

Du bekommst einen Plan mit Puffer, die drei wichtigsten Dinge und eine ehrliche Liste dessen, was diese Woche nicht mehr passt.

## Wenn etwas nicht klappt
- **Fehler beim Hochladen:** Die ZIP wurde entpackt oder umbenannt. Lade sie genau so hoch, wie sie im Ordner liegt.
- **Kein Bereich "Skills":** Prüfe in den Einstellungen nach "Skills" oder "Anpassen" und ob dein Tarif Skills enthält.
- **Claude nutzt den Skill nicht:** Schalte ihn in der Skills-Liste ein oder sage: "Nutze den Skill anfrage-beantworten."
- **Preise oder Ton stimmen nicht:** Starte den Chat im Projekt oder hänge `mein-geschaeft.md` an, und ergänze Beispiele unter "Mein Ton".

Claude kann Fehler machen. Prüfe Preise, Namen, Daten und Zahlen immer selbst.

## Mehr davon
Diese zwei Skills sind Teil des **Anfragen-Autopilot** (29 € einmalig, kein Abo). Dort kommen drei weitere dazu: Angebot erstellen, Beleg ordnen und Kunden-Nachfass, dazu eine ausführliche Schnellstart-Anleitung. Wenn dir die beiden hier reichen, ist das völlig in Ordnung.

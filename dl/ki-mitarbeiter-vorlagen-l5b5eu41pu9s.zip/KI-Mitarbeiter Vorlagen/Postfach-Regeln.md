# Postfach-Regeln

Sortiere in vier Gruppen: Wichtig (braucht mich), Rechnung/Beleg, Kann warten, Werbung.
- Rechnungen und Belege: nie löschen, in den Ordner "Belege" legen.
- Werbung: darf in den Papierkorb.
- Behördenpost, Zahlungs- und Kundenmails: nie löschen.
- Für die zwei wichtigsten Mails schreibst du einen Antwortentwurf, abgeschickt wird nur nach meinem Ja.

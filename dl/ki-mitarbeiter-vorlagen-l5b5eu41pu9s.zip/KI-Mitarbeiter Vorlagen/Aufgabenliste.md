# Aufgaben

## Heute
- [ ] 

## Diese Woche
- [ ] 

## Wartet auf andere
- [ ] 

## Irgendwann
- [ ] 

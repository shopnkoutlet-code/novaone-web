# Entscheidungen (neueste oben)

## [DATUM] – [Thema]
- Was entschieden ist:
- Warum:
- Was ab jetzt nicht mehr vorgeschlagen werden soll:

## Nein (nicht vorschlagen)
- 

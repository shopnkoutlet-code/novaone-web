# Morgen-Briefing (als geplante Aufgabe)

Erstelle mein Morgen-Briefing, kurz und gesprochen formuliert:
1. Termine heute
2. Mails, die eine Antwort brauchen (Absender und ein Satz)
3. Fristen dieser Woche
4. Meine Top-3 für heute aus 07 Aufgaben
5. Eine Empfehlung und ein Satz zum Schluss
Maximal 8 Sätze. Schreib das Ergebnis außerdem in 06 Tagebuch.

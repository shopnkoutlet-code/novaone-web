# Über mich

Name:
Beruf / Firma:
Was ich verkaufe oder tue:
Meine drei wichtigsten Ziele dieses Jahr:
1.
2.
3.
Wie ich arbeite (Zeiten, Gewohnheiten, was mich nervt):
Wichtige Menschen (Name, Rolle):
Vertraulich (nie in Texte für andere): 

#!/bin/bash
# Installer für den Alltags-Organisator (Mac)
QUELLE="$(cd "$(dirname "$0")" && pwd)/assistent"
ZIEL="$HOME/Alltags-Organisator"
export PATH="$HOME/.local/bin:/usr/local/bin:/opt/homebrew/bin:$PATH"
clear
echo "=== Alltags-Organisator installieren ==="
if [ ! -d "$QUELLE" ]; then echo "Ordner 'assistent' fehlt neben diesem Programm. Bitte das ZIP erst entpacken."; read -r; exit 1; fi

if [ -d "$ZIEL" ]; then
  echo "Update: Ihre Daten (profil.md, fristen.json, eingang) bleiben erhalten."
  rsync -a --exclude profil.md --exclude fristen.json --exclude eingang "$QUELLE/" "$ZIEL/"
else
  mkdir -p "$ZIEL" && rsync -a "$QUELLE/" "$ZIEL/"
fi
chmod +x "$ZIEL"/werkzeug/* "$ZIEL/Alltags-Organisator.command"

if ! xcode-select -p >/dev/null 2>&1; then
  echo "Der Mac braucht einmalig die Apple-Entwicklerwerkzeuge (kostenlos). Es öffnet sich gleich ein Fenster: bitte auf 'Installieren' klicken,"
  echo "warten bis es fertig ist, und danach dieses Programm noch einmal starten."
  xcode-select --install; read -r; exit 0
fi

if ! command -v claude >/dev/null 2>&1; then
  echo "Claude Code wird installiert (offizieller Installer von Anthropic) …"
  curl -fsSL https://claude.ai/install.sh | bash || { echo "Installation fehlgeschlagen. Bitte Internet prüfen und erneut starten."; read -r; exit 1; }
  export PATH="$HOME/.local/bin:$PATH"
fi

# Starter auf dem Schreibtisch zeigt auf den Ordner, damit Updates greifen
cat > "$HOME/Desktop/Alltags-Organisator.command" <<STARTER
#!/bin/bash
exec "$ZIEL/Alltags-Organisator.command"
STARTER
chmod +x "$HOME/Desktop/Alltags-Organisator.command"

echo
echo "Fertig. Auf Ihrem Schreibtisch liegt jetzt 'Alltags-Organisator'."
echo "Beim ersten Start öffnet sich der Browser: bitte mit Ihrem Claude-Konto (Pro oder Max) anmelden."
echo "Drücken Sie Enter, um jetzt zu starten."
read -r
open "$HOME/Desktop/Alltags-Organisator.command"

#!/usr/bin/env python3
"""Wetter in einer Zeile über Open-Meteo (ohne Konto, ohne Schlüssel). Aufruf: wetter.py "Stadt" """
import json, sys, urllib.parse, urllib.request

CODES = {0: "klar", 1: "überwiegend klar", 2: "wolkig", 3: "bedeckt", 45: "Nebel", 48: "Nebel", 51: "leichter Nieselregen",
         53: "Nieselregen", 55: "starker Nieselregen", 61: "leichter Regen", 63: "Regen", 65: "starker Regen",
         71: "leichter Schneefall", 73: "Schneefall", 75: "starker Schneefall", 80: "Schauer", 81: "Schauer",
         82: "starke Schauer", 95: "Gewitter", 96: "Gewitter mit Hagel", 99: "Gewitter mit Hagel"}


def holen(url):
    with urllib.request.urlopen(url, timeout=10) as r:
        return json.load(r)


try:
    stadt = sys.argv[1] if len(sys.argv) > 1 else "Berlin"
    ort = holen("https://geocoding-api.open-meteo.com/v1/search?count=1&language=de&name=" + urllib.parse.quote(stadt))["results"][0]
    w = holen("https://api.open-meteo.com/v1/forecast?timezone=auto&forecast_days=1"
              f"&latitude={ort['latitude']}&longitude={ort['longitude']}"
              "&current=temperature_2m,apparent_temperature,weather_code"
              "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max")
    c, d = w["current"], w["daily"]
    print(f"{ort['name']}: {CODES.get(c['weather_code'], 'wechselhaft')}, jetzt {c['temperature_2m']:.0f} Grad "
          f"(gefühlt {c['apparent_temperature']:.0f}), heute {d['temperature_2m_min'][0]:.0f} bis {d['temperature_2m_max'][0]:.0f} Grad, "
          f"Regenwahrscheinlichkeit {d['precipitation_probability_max'][0]} Prozent")
except Exception:
    print("Wetter gerade nicht erreichbar")

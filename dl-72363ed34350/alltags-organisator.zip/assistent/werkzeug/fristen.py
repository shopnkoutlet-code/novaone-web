#!/usr/bin/env python3
"""Fristen-Speicher des Alltags-Organisators. Nur Standardbibliothek."""
import json, os, sys, subprocess, datetime as dt

HIER = os.path.dirname(os.path.abspath(__file__))
ORDNER = os.path.dirname(HIER)
DATEI = os.path.join(ORDNER, "fristen.json")
PLIST = os.path.expanduser("~/Library/LaunchAgents/de.alltags-organisator.erinnerung.plist")


def laden():
    if not os.path.exists(DATEI):
        return []
    with open(DATEI, encoding="utf-8") as f:
        return json.load(f)


def speichern(liste):
    with open(DATEI, "w", encoding="utf-8") as f:
        json.dump(liste, f, ensure_ascii=False, indent=1)


def tage(eintrag):
    return (dt.date.fromisoformat(eintrag["datum"]) - dt.date.today()).days


def zeile(i, e):
    t = tage(e)
    wann = "heute" if t == 0 else f"in {t} Tagen" if t > 0 else f"seit {-t} Tagen überfällig"
    return f"{i}. {e['datum']} ({wann}) [{e.get('art','sonstiges')}] {e['titel']}" + (f" – {e['notiz']}" if e.get("notiz") else "")


def offen(liste):
    return [(i, e) for i, e in enumerate(liste, 1) if not e.get("erledigt")]


def neu(a):
    if len(a) < 2:
        sys.exit('Aufruf: neu "Titel" JJJJ-MM-TT ["Notiz"] [art]')
    try:
        dt.date.fromisoformat(a[1])
    except ValueError:
        sys.exit('Datum bitte als JJJJ-MM-TT, zum Beispiel 2026-12-31.')
    liste = laden()
    liste.append({"titel": a[0], "datum": a[1], "notiz": a[2] if len(a) > 2 else "",
                  "art": a[3] if len(a) > 3 else "sonstiges", "erledigt": False})
    speichern(liste)
    print("Eingetragen:", zeile(len(liste), liste[-1]))


def faellig(a):
    grenze = int(a[0]) if a else 14
    treffer = [(i, e) for i, e in offen(laden()) if tage(e) <= grenze]
    treffer.sort(key=lambda x: x[1]["datum"])
    print("\n".join(zeile(i, e) for i, e in treffer) or f"Nichts in den nächsten {grenze} Tagen fällig.")


def hinweis(a):
    """Für den täglichen Mac-Hinweis: Mitteilung nur, wenn etwas in 14/7/2 Tagen, heute oder überfällig ist."""
    treffer = [e for _, e in offen(laden()) if tage(e) in (14, 7, 2, 0) or tage(e) < 0]
    if not treffer:
        return
    text = "; ".join(f"{e['titel']} ({e['datum']})" for e in treffer[:3])
    text = text.replace('"', "'")
    subprocess.run(["osascript", "-e", f'display notification "{text}" with title "Alltags-Organisator: Frist"'])


def erinnerung_an(a):
    uhr = a[0] if a else "08:30"
    h, m = (int(x) for x in uhr.split(":"))
    os.makedirs(os.path.dirname(PLIST), exist_ok=True)
    with open(PLIST, "w") as f:
        f.write(f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>de.alltags-organisator.erinnerung</string>
<key>ProgramArguments</key><array><string>/usr/bin/python3</string><string>{os.path.abspath(__file__)}</string><string>hinweis</string></array>
<key>StartCalendarInterval</key><dict><key>Hour</key><integer>{h}</integer><key>Minute</key><integer>{m}</integer></dict>
</dict></plist>""")
    subprocess.run(["launchctl", "unload", PLIST], capture_output=True)
    subprocess.run(["launchctl", "load", PLIST])
    print(f"Tägliche Erinnerung um {uhr} Uhr eingeschaltet.")


def erinnerung_aus(a):
    if os.path.exists(PLIST):
        subprocess.run(["launchctl", "unload", PLIST], capture_output=True)
        os.remove(PLIST)
    print("Tägliche Erinnerung ausgeschaltet.")


def erledigt(a):
    liste = laden()
    liste[int(a[0]) - 1]["erledigt"] = True
    speichern(liste)
    print("Erledigt:", liste[int(a[0]) - 1]["titel"])


def zeigen(a):
    print("\n".join(zeile(i, e) for i, e in offen(laden())) or "Keine offenen Fristen.")


BEFEHLE = {"neu": neu, "faellig": faellig, "liste": zeigen, "erledigt": erledigt, "hinweis": hinweis,
           "erinnerung-an": erinnerung_an, "erinnerung-aus": erinnerung_aus}

if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] not in BEFEHLE:
        sys.exit("Befehle: " + ", ".join(BEFEHLE))
    BEFEHLE[sys.argv[1]](sys.argv[2:])

#!/bin/bash
# Startet den Alltags-Organisator
cd "$(dirname "$0")" || exit 1
export PATH="$HOME/.local/bin:/usr/local/bin:/opt/homebrew/bin:$PATH"
if ! command -v claude >/dev/null 2>&1; then
  echo "Claude Code fehlt noch. Bitte zuerst 'Alltags-Organisator installieren' ausführen."; read -r; exit 1
fi
clear
echo "Alltags-Organisator – einen Moment …"
if [ -f profil.md ]; then
  exec claude "Guten Morgen. Mach den Morgenüberblick."
else
  exec claude "Ich starte zum ersten Mal. Richte mich ein."
fi

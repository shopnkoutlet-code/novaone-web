---
name: fristen
description: Verträge, Rechnungen und Kündigungsfristen merken und rechtzeitig melden. Nutzen bei "trag ein", "wann läuft aus", "welche Fristen", Fotos oder PDFs von Verträgen und Rechnungen.
---
# Fristen und Papierkram
Speicher ist `fristen.json`, bedient nur über das Werkzeug:
- Eintragen: `python3 werkzeug/fristen.py neu "Titel" JJJJ-MM-TT "Notiz/Betrag" [art]` (art: zahlen, kuendigen, antworten, sonstiges)
- Liste: `python3 werkzeug/fristen.py liste`
- Bald fällig: `python3 werkzeug/fristen.py faellig 14`
- Erledigt: `python3 werkzeug/fristen.py erledigt <nr>`
- Mac-Erinnerung täglich: `python3 werkzeug/fristen.py erinnerung-an 08:30` / `erinnerung-aus`

Vorgehen bei einem Dokument (Foto, PDF, Text):
1. Lies Absender/Vertragspartner, Betrag, Fälligkeit, bei Verträgen Laufzeit, Verlängerung und Kündigungsfrist.
2. Rechne nach: Kündigungsfrist = Vertragsende minus Frist. Schreib in einem Satz, wie du gerechnet hast, und was im Dokument stand. Ist etwas unklar oder unleserlich, frag nur das eine nach.
3. Trag zwei Einträge ein, wenn sinnvoll: die Frist selbst und eine Vorwarnung 14 Tage vorher als eigenen Eintrag ("Vorwarnung: …"). Nicht doppelt eintragen: vorher `liste` ansehen.
4. Bestätige in zwei Sätzen: was, wann, dass es gemerkt ist.
Zahlen und Kündigen übernimmt die Person selbst. Biete bei Kündigungen einen Brief-Entwurf an.

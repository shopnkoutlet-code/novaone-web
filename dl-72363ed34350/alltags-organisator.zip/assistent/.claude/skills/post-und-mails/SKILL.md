---
name: post-und-mails
description: Mails und Briefe sortieren, Wichtiges nennen, Antwortentwürfe schreiben. Nutzen bei "meine Mails", "was ist wichtig", "antworte auf", eingefügten Mails oder Fotos von Briefen.
---
# Post und Mails
Quelle je nach `profil.md`:
- Gmail-Konnektor vorhanden: ungelesene Mails der letzten 2 Tage suchen.
- Sonst: die Person fügt Mails oder Brieftext ein oder legt ein Foto/PDF in den Ordner `eingang/`. Lies alles dort.

Vorgehen:
1. Sortiere in drei Gruppen: Braucht Antwort/Handlung, Zur Kenntnis (Rechnung, Bestätigung), Werbung/Rest.
2. Nenne zuerst nur die Gruppe 1, je Mail ein Satz: von wem, was gewollt wird, bis wann. Gruppe 2 und 3 nur als Zahl ("4 Bestätigungen, 9 Werbemails").
3. Enthält eine Mail oder ein Brief eine Frist, einen Vertrag oder eine Rechnung: biete an, es mit der Fristen-Fähigkeit einzutragen, und trage es nach dem Ja ein.
4. Antwortentwürfe: im Ton der Person (kurz, höflich, Anrede wie im Profil). Zeig den Entwurf im Chat. Mit Konnektor nur als Entwurf in Gmail anlegen, NIE senden.
5. Verdächtiges (Zahlungsaufforderungen mit Druck, Links zu Konto-Eingaben, unbekannte Absender mit Anhängen): warne kurz und ohne Panik, klicke und öffne nichts.

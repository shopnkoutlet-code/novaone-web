---
name: morgenueberblick
description: Morgenüberblick mit Terminen, Wetter und fälligen Fristen. Nutzen bei "Guten Morgen", "Was steht heute an", "Tagesüberblick".
---
# Morgenüberblick
1. `profil.md` lesen (Name, Stadt, Anrede). Fehlt sie: Einrichtung aus CLAUDE.md zuerst.
2. Wetter: `python3 werkzeug/wetter.py "<Stadt>"` (eine Zeile, Temperatur und Regen).
3. Termine heute und morgen: aus dem verbundenen Kalender (Google Calendar-Konnektor), falls vorhanden. Sonst einmal freundlich fragen: "Was steht heute an?" und das Gesagte verwenden.
4. Fristen: `python3 werkzeug/fristen.py faellig 14` (alles in den nächsten 14 Tagen).
5. Antworte in diesem Aufbau, höchstens 8 Zeilen, ohne Überschriften:
   - Begrüßung mit Namen und Wetter in einem Satz
   - Termine (Uhrzeit, Titel), das Wichtigste zuerst
   - Fristen, die bald fällig sind, mit Datum und was zu tun ist
   - Ein Satz: "Das Wichtigste heute: …"
Erfinde nichts. Fehlt eine Quelle, sag in einem Halbsatz, was fehlt und wie man es verbindet.

# Mein Alltag (diese Datei liegt im Projekt bzw. Gem)
Hinweis: Ersetze alles in [eckigen Klammern]. Oder lass dir beim ersten Start vom Assistenten alles ausfüllen: Schreibe einfach "Guten Morgen".

- Name des Assistenten: [Konrad]
- Anrede: [du oder Sie] / Mein Name: [Vorname]
- Stadt: [Stadt]
- Postfach: [Gmail, Outlook oder anderes]
- Das nervt am meisten: [Mails, Termine oder Papierkram]

## Fristen
Format: JJJJ-MM-TT | Titel | Notiz oder Betrag | Art (zahlen, kündigen, antworten, sonstiges)
- [noch keine]

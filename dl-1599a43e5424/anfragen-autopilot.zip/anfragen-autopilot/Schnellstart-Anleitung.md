# Was du bekommst

Der Anfragen-Autopilot besteht aus fünf fertigen Skills für Claude und einer Datei, in der dein Geschäft steht. Ein Skill ist eine Arbeitsanweisung, die Claude automatisch benutzt, sobald du etwas Passendes sagst. Du installierst nichts auf deinem Rechner und programmierst nichts. Alles läuft in deinem eigenen Claude-Konto im Browser oder in der App.

Die fünf Skills:

| Skill | Das sagst du | Das bekommst du |
|---|---|---|
| anfrage-beantworten | "Antworte auf diese Nachricht" und die Nachricht einfügen | Antwortentwurf in deinem Ton, mit Rückfragen zu fehlenden Angaben |
| angebot-erstellen | "Mach ein Angebot für ..." | Angebot mit Positionen, Summen, Gültigkeit und Zahlungsbedingungen |
| beleg-ordnen | Foto oder PDF einer Rechnung hochladen | Betrag, Datum, Fälligkeit, Dateiname und eine Übersicht aller Belege |
| wochenplan | "Plan meine Woche" und deine Aufgaben nennen | Wochenplan mit Blöcken und einer ehrlichen Liste dessen, was nicht passt |
| kunden-nachfass | "Wer hat sich nicht gemeldet?" und deine offenen Vorgänge einfügen | Übersicht und freundliche Nachfass-Entwürfe |

Dazu kommt die Datei `mein-geschaeft.md`. Dort steht, was du anbietest, was es kostet, wie du schreibst und wann du Zeit hast. Alle fünf Skills lesen sie. Du füllst sie einmal aus und pflegst sie, wenn sich etwas ändert.

> Wichtig: Die Skills schreiben Entwürfe und Vorschläge. Sie senden nichts ab, sie zahlen nichts und sie haben keinen Zugriff auf dein Postfach oder deine Instagram-Nachrichten. Du kopierst die Nachricht hinein und das Ergebnis wieder heraus. Alles Verbindliche prüfst und sendest du selbst.

# Das brauchst du

- Ein Konto bei Claude (claude.ai) mit Claude Pro oder Max (das kostenlose Claude reicht nicht). Skills und die nötige Funktion "Code-Ausführung und Dateierstellung" gehören zu den bezahlten Tarifen. Für die Tarife und Preise gilt die Seite von Anthropic, nicht diese Anleitung.
- Einen Browser (Chrome, Safari, Firefox, Edge) oder die Claude-Desktop-App. Auf dem Handy kannst du die Skills nutzen, aber nicht hochladen. Das Hochladen geht am Computer.
- Etwa 25 Minuten für die Einrichtung. Davon sind 15 Minuten das Ausfüllen von `mein-geschaeft.md`.
- Keine Programmierkenntnisse, keinen Installer, kein Terminal.
- Du nutzt Google statt Claude? Dann nimm die Gemini-Fassung im Ordner `gemini` (Google AI Pro nötig, Anleitung dort). Die Schritte unten gelten für Claude.
- Sonst nichts: keine weiteren kostenpflichtigen Programme, Plugins oder Abos. Alle fünf Skills laufen allein in deinem Claude.

> Hinweis zu den Menüs: Anthropic ändert Bezeichnungen und Menüs gelegentlich. Die Schritte unten beschreiben den Stand vom November 2026. Findest du einen Punkt nicht, suche in den Einstellungen nach "Skills" oder "Fähigkeiten" oder schau in die Hilfeseite von Claude unter "Skills". Die Screenshot-Platzhalter in dieser Anleitung ersetzen wir durch aktuelle Bilder.

<!-- seite -->
# Schritt 1: Paket auspacken

1. Lade die Datei `anfragen-autopilot.zip` herunter und entpacke sie. Auf dem Mac genügt ein Doppelklick, unter Windows "Alle extrahieren".
2. Du findest darin: diese Anleitung, die Datei `mein-geschaeft.md`, den Ordner `skills` und den Ordner `beispiele`.
3. Im Ordner `skills` liegen fünf ZIP-Dateien, eine pro Skill. Entpacke sie nicht. Du lädst sie gleich genau so hoch.

[BILD: Der entpackte Ordner mit den Dateien: Anleitung, mein-geschaeft.md, Ordner skills (fünf ZIP-Dateien), Ordner beispiele]

# Schritt 2: Code-Ausführung einschalten

Skills brauchen in Claude die Funktion "Code-Ausführung und Dateierstellung". Das ist nur ein Schalter.

1. Öffne claude.ai und melde dich an.
2. Klicke unten links auf deinen Namen und dann auf **Einstellungen**.
3. Öffne den Bereich **Funktionen** (je nach Version auch "Capabilities" genannt).
4. Schalte **Code-Ausführung und Dateierstellung** ein. Steht der Schalter schon auf "an", bist du hier fertig.

[BILD: Einstellungen, Bereich Funktionen, der Schalter "Code-Ausführung und Dateierstellung" ist markiert]

# Schritt 3: Die fünf Skills hochladen

Das machst du fünfmal, einmal pro ZIP-Datei.

1. Öffne in den Einstellungen den Bereich **Skills** (bei manchen Versionen unter "Anpassen" oder "Customize", dann "Skills").
2. Klicke auf das **Plus**, dann auf **Skill erstellen** und **Skill hochladen**.
3. Wähle eine der ZIP-Dateien aus dem Ordner `skills`, zum Beispiel `anfrage-beantworten.zip`.
4. Warte, bis der Skill in der Liste steht, und achte darauf, dass der Schalter daneben auf "an" steht.
5. Wiederhole das mit `angebot-erstellen.zip`, `beleg-ordnen.zip`, `wochenplan.zip` und `kunden-nachfass.zip`.

[BILD: Skills-Seite mit dem Plus-Knopf und dem Menüpunkt "Skill hochladen"]

[BILD: Liste mit allen fünf Skills, alle Schalter auf "an"]

Gut zu wissen:
- Hochgeladene Skills sind nur für dein Konto sichtbar.
- Ein Skill, der in claude.ai hochgeladen wurde, gilt nur dort. Willst du ihn auch an anderer Stelle nutzen (zum Beispiel in Claude Code), musst du ihn dort separat einrichten.
- Meldet Claude beim Hochladen einen Fehler, siehe "Typische Fehler" weiter unten.

<!-- seite -->
# Schritt 4: Dein Geschäft eintragen (15 Minuten)

Jetzt bekommen die Skills ihr Gedächtnis. Ohne diese Datei fragen sie dich bei jeder Aufgabe nach den Grundlagen. Mit der Datei kennen sie dein Geschäft von Anfang an.

1. Öffne `mein-geschaeft.md`. Das ist eine normale Textdatei. Du kannst sie mit dem Editor (Windows), TextEdit (Mac) oder einem beliebigen Textprogramm öffnen. Auf dem Mac stellst du TextEdit vorher auf "Reiner Text" (Menü Format).
2. Ersetze alles in [eckigen Klammern] durch deine Angaben. Was du nicht weißt, lässt du leer oder schreibst "offen".
3. Nimm dir Zeit für zwei Abschnitte, weil sie am meisten bewirken:
   - **Leistungen und Preise:** Trage jede Leistung mit Preis und Einheit ein. Der Skill "angebot-erstellen" nimmt Preise nur von hier. Was nicht in der Tabelle steht, kann er nicht berechnen.
   - **Mein Ton:** Kopiere zwei oder drei echte Nachrichten von dir hinein (Namen ändern, wenn du magst). Je echter die Beispiele, desto mehr klingen die Entwürfe nach dir. Schreibe auch auf, welche Wörter du nie benutzt.
4. Speichere die Datei.

Nun legst du einen Ort an, an dem Claude die Datei immer findet. Der einfachste Weg ist ein Projekt:

1. Klicke in Claude links auf **Projekte** und dann auf **Neues Projekt**.
2. Nenne es "Mein Geschäft".
3. Füge im Bereich **Projektwissen** (oder "Dateien") die Datei `mein-geschaeft.md` hinzu.
4. Starte künftig alle Chats für dein Geschäft **in diesem Projekt**. Dort liegt die Datei immer bereit.

[BILD: Neues Projekt "Mein Geschäft" mit der Datei mein-geschaeft.md im Projektwissen]

> Hast du kein Projekt, geht es auch ohne: Hänge `mein-geschaeft.md` mit der Büroklammer an die erste Nachricht des Chats an, oder füge ihren Inhalt in die Nachricht ein. Das ist nur umständlicher, weil du es bei jedem neuen Chat wiederholst.

# Schritt 5: Dein erstes Ergebnis (ca. 10 Minuten)

Teste mit einer echten oder einer ausgedachten Anfrage. Öffne einen neuen Chat in deinem Projekt "Mein Geschäft" und schreibe:

```
Antworte bitte auf diese Instagram-Nachricht:
"Hey, machst du auch [deine Leistung]? Was kostet das ungefähr? Lg Sandra"
```

Setze bei [deine Leistung] etwas ein, das du wirklich anbietest. Was jetzt passiert:

1. Claude erkennt, dass dazu der Skill "anfrage-beantworten" passt, und nutzt ihn. Du siehst das meist an einem kleinen Hinweis wie "Skill verwendet".
2. Du bekommst drei Teile: "Kurz verstanden", einen "Entwurf" und, wenn nötig, einen "Hinweis für dich".
3. Prüfe den Entwurf: Stimmt der Preis? Klingt es nach dir? Passt der nächste Schritt?
4. Kopiere ihn in Instagram, ändere ihn nach Belieben und sende ihn selbst ab.

[BILD: Chat im Projekt: oben deine Nachricht, darunter die Antwort mit "Kurz verstanden", "Entwurf", "Hinweis für dich"]

Passt der Ton nicht, sage es: "Kürzer und lockerer, ohne Ausrufezeichen." Trage dann diese Vorliebe unter "Mein Ton" in `mein-geschaeft.md` ein, damit es künftig von Anfang an stimmt.

Geschafft: Damit läuft der erste Skill. Die anderen vier funktionieren genauso.

<!-- seite -->
# Die fünf Skills im Alltag

## 1. Anfrage beantworten
Sage: "Antworte darauf:" und füge die Nachricht ein (Mail, Instagram-DM, WhatsApp, Kontaktformular). Der Skill stellt höchstens vier Rückfragen an den Kunden in die Antwort ein, nur zu dem, was wirklich fehlt. Passt die Anfrage nicht zu deinem Angebot (zu weit weg, nicht dein Thema), schreibt er eine freundliche Absage.

Tipp: Gib bei Bedarf zusätzlich Hinweise mit, zum Beispiel "Der Kunde ist ein Stammkunde" oder "Biete ihm den Samstag an".

## 2. Angebot erstellen
Sage: "Mach ein Angebot für Frau Meier: [Leistungen], Ort [Ort]." Nenne Namen und, falls du sie hast, die Anschrift des Kunden. Der Skill rechnet aus deiner Preisliste, rechnet nach und setzt Nummer, Datum, Gültigkeit und Zahlungsbedingungen ein. Am Ende steht eine Liste "Bitte prüfen" mit allen Annahmen.

- Mit eingeschalteter Dateierstellung liefert Claude eine .docx-Datei, die du herunterladen kannst. Sie öffnet sich auch in kostenlosen Programmen wie LibreOffice oder Google Docs. Sonst bekommst du den Text mit Tabelle zum Kopieren.
- Fehlt für eine gewünschte Leistung der Preis, steht dort `[PREIS FEHLT]` und der Skill fragt nach.
- Trage die vergebene Angebotsnummer danach in `mein-geschaeft.md` unter "Letzte vergebene Angebotsnummer" ein.

## 3. Rechnung oder Beleg ordnen
Lade ein Foto oder PDF hoch und schreibe "Ordne diesen Beleg ein" oder "Wann muss ich zahlen?". Der Skill liest Aussteller, Nummer, Datum, Betrag, Umsatzsteuer und Fälligkeit, schlägt Kategorie und Dateinamen vor und führt eine Übersicht.

- Mehrere Belege gehen auf einmal. Die Übersicht wird dann nach Fälligkeit sortiert.
- Ist etwas unleserlich, schreibt der Skill ein Fragezeichen und fragt nach. Er rät keine Beträge.
- Für die nächste Runde lädst du die letzte Übersicht (als Datei oder eingefügt) wieder mit hoch. Dann schreibt er sie fort.
- Der Skill ordnet nur. Er bucht nichts und beurteilt keine Steuerfragen. Überweisen musst du selbst.

## 4. Wochenplan
Sage: "Plan meine Woche" und schreibe deine Aufgaben auf, so durcheinander, wie sie sind. Nenne feste Termine und, wenn sie nicht in `mein-geschaeft.md` stehen, deine freien Zeiten. Der Skill plant mit Puffer, setzt Prioritäten und sagt dir, was diese Woche nicht mehr passt.

Ändert sich etwas ("Dienstag fällt aus"), schreibe es dazu. Er passt nur die betroffenen Tage an.

## 5. Kunden-Nachfass
Sage: "Wer hat sich nicht gemeldet?" und liste deine offenen Vorgänge auf: Name, was geschickt wurde, Datum. Der Skill zählt die Tage, sagt dir, wer jetzt dran ist, wer noch warten kann und wo du besser abschließt, und schreibt freundliche Nachfass-Entwürfe ohne Druck.

Mahnungen und Zahlungserinnerungen schreibt dieser Skill nicht.

<!-- seite -->
# Typische Fehler und was du tun kannst

| Problem | Ursache | Lösung |
|---|---|---|
| Beim Hochladen kommt ein Fehler | Die ZIP wurde entpackt oder umbenannt, oder ein Ordner liegt noch in einem Ordner | Lade die ZIP genau so hoch, wie sie im Ordner `skills` liegt. Entpacke sie nicht. |
| Es gibt keinen Bereich "Skills" | Dein Tarif oder deine Version ist anders, oder die Funktion heißt anders | Prüfe in den Einstellungen nach "Skills" oder "Anpassen". Prüfe, ob dein Tarif Skills enthält (Claude Pro oder höher) und die Code-Ausführung an ist. |
| Claude nutzt den Skill nicht | Der Skill ist ausgeschaltet oder deine Formulierung passt nicht | Schalte ihn in der Skills-Liste ein. Sage ausdrücklich: "Nutze den Skill anfrage-beantworten." |
| Claude fragt nach Preisen, die in der Datei stehen | Die Datei ist nicht im Projekt oder nicht angehängt | Starte den Chat im Projekt "Mein Geschäft" oder hänge `mein-geschaeft.md` an. |
| Antwort klingt nicht nach mir | Zu wenig echte Beispiele unter "Mein Ton" | Füge drei echte Nachrichten ein, auch kurze. Schreibe Wörter auf, die du nie benutzt. |
| Im Angebot steht [PREIS FEHLT] | Die Leistung steht nicht in deiner Preisliste | Trage den Preis in `mein-geschaeft.md` ein oder nenne ihn im Chat. |
| Es kommt keine Angebotsdatei | Dateierstellung ist aus oder dein Tarif bietet sie nicht | Schalte "Code-Ausführung und Dateierstellung" an. Sonst kopiere den Text in dein eigenes Dokument. |
| Der Skill sagt, ein Foto sei unlesbar | Das Bild ist unscharf, schräg oder zu dunkel | Fotografiere neu bei Tageslicht, gerade von oben. Oder lade das PDF des Anbieters hoch. |
| Das Nutzungslimit ist erreicht | Claude hat in deinem Tarif ein Limit pro Zeitraum | Warte, bis es zurückgesetzt wird, oder nutze deinen Tarif sparsamer. Der Autopilot verändert dein Limit nicht. |
| Die Antwort enthält etwas Falsches | Claude kann sich irren | Prüfe Preise, Daten, Namen und Zahlen vor dem Versenden immer selbst. Das ist Teil des Ablaufs. |

# Gut zu wissen

**Was an Claude geht.** Alles, was du in den Chat schreibst oder hochlädst, geht an Anthropic, den Betreiber von Claude, und unterliegt den Regeln deines Kontos. Lade nur hoch, was du dort haben willst. Namen und Anschriften deiner Kunden sind personenbezogene Daten. Entscheide selbst, welche du eingibst, und beachte die Regeln, die für dein Geschäft gelten. Du kannst Namen in den Beispielen abkürzen oder ändern, wenn sie für das Ergebnis nicht nötig sind.

**Was die Skills nicht können.**
- Sie senden nichts ab und lesen kein Postfach. Du kopierst hinein und heraus.
- Sie wissen nur, was in `mein-geschaeft.md` und im Chat steht. Ändern sich deine Preise, ändere die Datei.
- Sie sind kein Steuer- oder Rechtsrat. Sie rechnen und ordnen, du entscheidest.
- Claude kann Fehler machen. Prüfe jedes Ergebnis, bevor es zum Kunden geht.

**Aktualisieren.** Ändert sich ein Skill, bekommst du eine neue ZIP-Datei. Dann löschst du den alten Skill in der Liste und lädst den neuen hoch.

**Skills anpassen.** Jeder Skill ist ein Ordner mit einer Textdatei (`SKILL.md`). Du kannst sie in einem Texteditor öffnen und zum Beispiel die Länge der Antworten oder das Ausgabeformat ändern. Packe den Ordner danach wieder zu einer ZIP-Datei und lade ihn neu hoch. Wenn du nichts ändern willst, lass die Dateien, wie sie sind.

**Die Beispiele.** Im Ordner `beispiele` liegen zehn Beispielergebnisse (zwei pro Skill) mit erfundenen Personen, damit du siehst, wie ein Ergebnis aussieht.

**Hilfe.** Schreibe uns an kontakt@novaone-group.de, wenn etwas nicht funktioniert. Schicke dazu nur, was du loswerden willst: Du musst keine Kundendaten mitschicken.

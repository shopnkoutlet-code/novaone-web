# Mein Geschäft

Diese Datei ist das Gedächtnis für alle fünf Skills. Fülle sie einmal aus (ca. 15 Minuten). Alles in [eckigen Klammern] ersetzt du durch deine Angaben. Was du nicht weißt, lässt du leer oder schreibst "offen", dann fragt dich der Skill bei Bedarf danach.

Wichtig: Je echter die Beispiele bei "Mein Ton" sind, desto mehr klingen die Entwürfe nach dir. Kopiere dort zwei oder drei echte Nachrichten von dir hinein.

## 1. Wer ich bin
- Name: [Vor- und Nachname]
- Firmen- oder Geschäftsname: [z. B. Max Mustermann Webdesign, oder nur dein Name]
- Was ich mache (ein Satz): [z. B. Ich fotografiere Hochzeiten und Familien in Augsburg und Umgebung.]
- Hauptberuf oder Nebengewerbe: [z. B. Nebengewerbe, Hauptberuf Mo bis Fr 8 bis 16 Uhr]
- Anschrift (für Angebote und Rechnungen): [Straße Nr., PLZ Ort]
- Region, in der ich arbeite: [z. B. Augsburg und 50 km Umkreis]

## 2. Meine Leistungen und Preise
Trage hier ein, was du anbietest. Der Skill "Angebot erstellen" nimmt die Preise nur von hier.

| Leistung | Was enthalten ist | Preis | Einheit |
|---|---|---|---|
| [Leistung 1] | [kurz] | [z. B. 120,00 €] | [Stunde / Stück / pauschal] |
| [Leistung 2] | [kurz] | [Preis] | [Einheit] |
| [Leistung 3] | [kurz] | [Preis] | [Einheit] |

- Anfahrt: [z. B. 0,50 € pro km ab 20 km, oder inklusive]
- Was ich nicht anbiete: [z. B. Videos, Aufträge außerhalb Bayerns]
- Mindestauftrag: [z. B. 1 Stunde, oder keiner]

## 3. Steuer, Zahlung, Angebote
- Umsatzsteuer: [Kleinunternehmer nach § 19 UStG, keine Umsatzsteuer ausgewiesen / Regelbesteuerung mit 19 % / 7 % bei ...]
- Zahlungsziel: [z. B. 14 Tage netto]
- Anzahlung: [z. B. 30 % bei Auftrag, oder keine]
- Bankverbindung für Angebote und Rechnungen: [IBAN, Kontoinhaber]
- Angebot gültig für: [z. B. 14 Tage]
- Nummernschema für Angebote: [z. B. A-2026-001, A-2026-002 ...]
- Letzte vergebene Angebotsnummer: [z. B. A-2026-004]

## 4. Mein Ton
- Anrede der Kunden: [Ich duze fast immer / Ich siez(e) fast immer / Je nachdem, wie die Person schreibt]
- So würde ich mich beschreiben: [z. B. herzlich, kurz, ohne Floskeln]
- Wörter, die ich gern benutze: [z. B. "Hallo", "super", "gern"]
- Wörter und Sätze, die ich nie benutze: [z. B. "Sehr geehrte Damen und Herren", "Mit freundlichen Grüßen"]
- Meine Grußformel: [z. B. "Liebe Grüße" / "Viele Grüße"]
- Meine Signatur:

```
[Name]
[Geschäftsname]
[Telefon] | [E-Mail] | [Webseite]
```

Echte Beispiele von mir (kopiere 2 bis 3 echte Nachrichten hierher, Namen darfst du ändern):

> Beispiel 1: [Eine echte Antwort von dir an einen Kunden]

> Beispiel 2: [Noch eine echte Antwort, gern kürzer, z. B. auf eine Instagram-Nachricht]

## 5. Meine Zeit
- Wann ich arbeite: [z. B. Mo bis Fr ab 17 Uhr, Sa ganztags]
- Wie viele Stunden pro Woche ich für das Geschäft habe: [z. B. 12]
- Feste Termine, die immer gleich sind: [z. B. Di 18 Uhr Training, Sonntag frei]
- Wann ich antworte: [z. B. innerhalb von 24 Stunden]
- Urlaub / Sperrzeiten: [z. B. 20. bis 31. Dezember]

## 6. Belege und Ablage
- Kategorien für Belege: [z. B. Material, Software und Abos, Fahrtkosten, Werbung, Fortbildung, Sonstiges]
- Dateinamen-Schema: [Standard: JJJJ-MM-TT_Aussteller_Betrag, z. B. 2026-10-14_Adobe_24-39]
- Meine Ablage-Ordner: [z. B. Belege/2026/Oktober]
- Das ist privat und gehört nicht ins Geschäft: [z. B. Supermarkt, Kleidung]

## 7. Nachfassen
- Nachfassen nach einem Angebot: nach [5] Tagen ohne Antwort
- Nachfassen nach einer Anfrage, wenn ich eine Frage gestellt habe: nach [3] Tagen
- Wie oft ich höchstens nachfasse: [2]
- Wie ich nachfrage: [z. B. locker, ohne Druck]

## 8. Meine Regeln
- Das sage ich nie zu: [z. B. Rabatte über 10 %, Termine am Sonntag, Aufträge ohne Anzahlung]
- Das ist mir wichtig: [z. B. Ich lasse mir bei Hochzeiten immer ein Vorgespräch geben]
- Sonstiges: [alles, was ein Assistent wissen sollte]

# Anfragen-Autopilot für Gemini (Gem)

Die fünf Skills laufen auch in Google Gemini, als "Gem" mit Wissensdateien. Getestet haben wir das mit **Google AI Pro** (ehemals Gemini Advanced). Ob es mit dem kostenlosen Gemini geht, haben wir nicht geprüft und versprechen es nicht.

> Hinweis: Google stellt Gems ab dem 17. November 2026 automatisch auf "Skills" um. Deine Dateien und Anleitung bleiben dabei erhalten. Die Menüs können danach anders heißen.

## Das brauchst du
- Ein Google-Konto mit **Google AI Pro** (Abo bei Google, nicht im Preis enthalten).
- Etwa 15 Minuten.

## In 5 Schritten startklar
1. Öffne `mein-geschaeft.md` in einem Texteditor, ersetze alles in [eckigen Klammern] mit deinen Angaben (siehe Schnellstart-Anleitung, Schritt "Geschäft eintragen") und speichere.
2. Gehe auf gemini.google.com, links **Gems**, dann **Neues Gem**.
3. **Name:** "Anfragen-Autopilot". **Anleitung:** kopiere den Text aus `gem-anleitung.txt` (liegt im Ordner).
4. Unter **Wissen** lädst du alle sechs Dateien hoch: `mein-geschaeft.md` und die fünf Dateien `skill-....md`. Warte, bis alle sechs angezeigt werden.
5. Auf **Speichern** klicken. Im Gem-Chat schreibst du zum Beispiel: "Antworte darauf: [Nachricht]" oder "Mach ein Angebot für ...".

## Was anders ist als bei Claude
- Du lädst keine ZIP-Skills hoch, sondern Dateien ins Wissen eines Gems. Der passende Skill wird nach deinem Wunsch ausgewählt.
- Die Antworten kommen manchmal langsamer (bis zu ein paar Minuten bei Angeboten).
- Gemini kann Word-Dateien nicht immer erstellen. Dann bekommst du den Text mit Tabelle zum Kopieren.
- Nach der Gems-Umstellung am 17.11.2026 prüfe, ob die Wissensdateien noch am Gem hängen.
- Wie immer: Preise, Namen, Daten und Summen vor dem Senden selbst prüfen. Der Autopilot schreibt nur Entwürfe.

## Test (Stand 02.11.2026)
Gem mit allen sechs Dateien: Anfrage beantworten funktionierte im Format des Skills ("Kurz verstanden", "Entwurf"). Angebot erstellen im normalen Gemini-Chat mit den Dateien: Gesamtsumme 316,00 €, Nummer A-2026-005, wie im Claude-Beispiel. Die übrigen drei Skills sind in Gemini nicht einzeln getestet.

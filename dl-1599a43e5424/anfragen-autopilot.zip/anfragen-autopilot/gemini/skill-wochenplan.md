---
name: wochenplan
description: Macht aus einer ungeordneten Aufgabenliste und den festen Terminen der Woche einen realistischen Wochenplan mit Tagesblöcken, Prioritäten und einer ehrlichen Liste dessen, was diese Woche nicht mehr passt. Berücksichtigt Hauptberuf, Nebengewerbe und Pufferzeit. Nutze diesen Skill, wenn der Nutzer sagt "Wochenplan", "plan meine Woche", "ich habe zu viel zu tun", "was mache ich zuerst", "Aufgaben sortieren", "Prioritäten für diese Woche" oder eine Liste von Aufgaben und Terminen einfügt.
---

# Wochenplan

Du machst aus einem Haufen Aufgaben und Terminen einen Plan, der in die echte Woche des Nutzers passt. Du planst nicht alles hinein, sondern zeigst auch, was nicht passt.

## Vorbereitung

1. Suche `mein-geschaeft.md` (Projektwissen, Anhang oder Chat). Du brauchst Abschnitt 5 (Arbeitszeiten, Stunden pro Woche, feste Termine, Antwortzeit, Urlaub) und die Regeln in Abschnitt 8.
2. Frage, falls nicht vorhanden oder unklar, in einer einzigen Nachricht höchstens drei Dinge: (a) In welcher Woche planen wir (Datum von Montag)? (b) Welche festen Termine gibt es? (c) Wie viele Stunden hast du wirklich frei? Arbeite danach weiter.
3. Nimm die Aufgaben so, wie der Nutzer sie liefert: Stichpunkte, Sprachnotiz-Text, durcheinander. Du brauchst keine saubere Liste.

## Schritte

1. **Rahmen setzen.** Lege die festen Termine zuerst in die Woche. Rechne daraus pro Tag die frei nutzbaren Stunden aus. Ziehe 20 bis 30 Prozent Puffer ab (Unvorhergesehenes, Kundenfragen beantworten, Wege). Nenne die Rechnung in einem Satz ("Du hast ca. 11 Stunden netto, ich plane 8 verbindlich").
   Feste Termine, die zum Geschäft gehören (zum Beispiel ein Kundentermin), zählen als Geschäftsstunden. Private feste Termine (Training, Familie) blockieren nur die Zeit. Nennt der Nutzer keine Dauer, schätze sie (Kundentermin: eine Stunde) und kennzeichne es. Die Stunden pro Woche aus der Datei sind die Obergrenze; die Zeitfenster sagen nur, wann gearbeitet werden kann. Nenne den Puffer als Zahl (Standard 25 Prozent). Steht kein Ende für die Abende in der Datei, plane höchstens zwei Stunden pro Abend und sage das.
2. **Aufgaben aufnehmen.** Mache aus jeder Aufgabe eine Zeile mit: Aufgabe, geschätzte Dauer, Frist (falls genannt), Wirkung (bringt Geld, hält einen Kunden zufrieden, räumt auf, kann warten). Schätzungen der Dauer kennzeichnest du als Schätzung und fragst, wenn eine Schätzung die Planung stark verändert.
3. **Priorisieren.** In dieser Reihenfolge:
   - Aufgaben mit fester Frist in dieser oder der nächsten Woche
   - Aufgaben, bei denen ein Kunde wartet oder die Geld bringen (Angebote, Rechnungen, Nachfassen)
   - Aufgaben, die andere Aufgaben blockieren (sie kommen vor der blockierten Aufgabe)
   - Aufräumen, Ideen, Sonstiges
   Sage bei Zielkonflikten kurz, warum du so entschieden hast, und bleibe dabei, außer der Nutzer widerspricht.
4. **Verteilen.** Plane in Blöcken von 30 bis 90 Minuten. Arbeiten, die Tageslicht oder besondere Bedingungen brauchen (Außenarbeit, Fotografie), legst du nur in Zeiten, in denen das möglich ist; weißt du die Zeiten nicht genau, nenne deine Schätzung (zum Beispiel Sonnenuntergang) und kennzeichne sie. Schreibtischarbeit kommt in die übrigen Zeiten. Aufgaben, die länger als 90 Minuten dauern, teilst du auf mehrere Blöcke auf oder setzt sie als bewusst langen Block (zum Beispiel am Samstag). Fällt eine Frist auf einen Tag ohne Arbeitszeit, plane die Aufgabe früher und nenne das Risiko. Setze anspruchsvolle Aufgaben in die Zeiten, die der Nutzer als ruhig oder fit beschreibt (steht nichts in der Datei, frage nicht nach, sondern lege sie auf den ersten freien längeren Block). Lege kleine Aufgaben (Mails, Anrufe) zu einem Block zusammen. Halte mindestens einen Tag oder Halbtag frei, wenn die Datei freie Zeiten nennt.
5. **Nicht Passendes ehrlich benennen.** Passt eine Aufgabe nicht, setze sie nicht heimlich in einen überfüllten Tag. Schreibe sie in "Passt diese Woche nicht" und mache einen Vorschlag: verschieben auf [Tag nächste Woche], kleiner machen, abgeben oder streichen.
6. **Ausgabe in diesem Format:**
   - **Auf einen Blick:** drei Sätze: wie viel Zeit, wie viel verplant, die drei wichtigsten Dinge der Woche.
   - **Plan:** Tabelle mit Spalten Tag, Zeit/Block, Aufgabe, Dauer, Frist/Hinweis. Feste Termine in Fettschrift.
   - **So habe ich entschieden:** zwei bis vier kurze Stichpunkte (Reihenfolge, Annahmen, Schätzungen, Risiken).
   - **Passt diese Woche nicht:** Liste mit Vorschlag je Eintrag. Entfällt, wenn alles passt.
   - **Zum Kopieren:** auf Wunsch jede Zeile als einfacher Text (Tag, Uhrzeit, Titel), den der Nutzer in seinen Kalender übertragen kann.
7. **Nachjustieren.** Meldet der Nutzer später "Dienstag fällt aus" oder "X ist dazugekommen", passe nur die betroffenen Tage an und sage, was sich verschiebt.

## Regeln

- Plane keine Zeiten, die der Nutzer als belegt oder gesperrt genannt hat, und keine Nacht- oder Sonntagsarbeit, die er ausgeschlossen hat.
- Keine Versprechen über Ergebnisse ("Damit schaffst du alles"). Der Plan ist ein Vorschlag.
- Du trägst nichts in einen Kalender ein und hast keinen Zugriff auf einen Kalender. Du lieferst den Text.
- Erfinde keine Termine und keine Fristen. Fehlt eine Frist, steht dort "keine Frist genannt".
- Sprich den Nutzer so an, wie er mit dir schreibt (du oder Sie).
- Bleibe bei dem, was der Nutzer genannt hat: Hauptberuf und Familie sind feste Grenzen, keine Verfügungsmasse.

## Beispiele

**Beispiel 1: Aufgabenhaufen**

Eingabe: "Diese Woche: Angebot für Familie Lorenz, Rechnung an Herrn Schulte schreiben, Belege vom Oktober sortieren, Instagram-Beiträge planen, neues Portfolio-Foto aussuchen. Ich habe Mo bis Do ab 18 Uhr Zeit, Samstag vormittags. Mittwoch 19 Uhr Kundentermin."

Ausgabe: Auf einen Blick: ca. 11 Stunden brutto, 8 Stunden verplant. Zuerst Angebot Lorenz (Kunde wartet) und Rechnung Schulte (Geld). Plan: Mo 18:00 bis 19:00 Angebot Lorenz; Di 18:00 bis 18:45 Rechnung Schulte; Mi **19:00 Kundentermin**; Do 18:00 bis 19:30 Belege sortieren; Sa 9:00 bis 10:30 Instagram planen. Passt diese Woche nicht: Portfolio-Foto aussuchen, Vorschlag: nächsten Samstag.

**Beispiel 2: zu viel für zu wenig Zeit**

Eingabe: 14 Aufgaben mit 20 Stunden Schätzung, der Nutzer hat 6 Stunden. (Beispiel mit erfundenen Zahlen)

Ausgabe: Ehrliche Rechnung (6 Stunden minus Puffer = 4,5 Stunden planbar), drei Aufgaben im Plan, drei Aufgaben als "mit Mini-Version", acht Aufgaben bei "Passt diese Woche nicht" mit je einem Vorschlag.

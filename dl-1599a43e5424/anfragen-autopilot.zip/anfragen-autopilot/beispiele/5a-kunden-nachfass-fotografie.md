# Beispiel: Kunden-Nachfass

*Alle Personen, Firmen und Beträge sind erfunden. Geschäft: Fotografin.*

**Das wurde eingegeben:** Fünf offene Vorgänge (Angebote, eine Rückfrage, eine Absage, zwei Nachfassungen ohne Antwort).

**So antwortet Claude mit dem Skill:**

---

Stand heute, Montag 2.11.2026. Ich nutze deine Regeln aus dem Dokument: Angebot ohne Antwort nach 5 Tagen, Rückfrage ohne Antwort nach 3 Tagen, höchstens 2 Nachfassungen.

## Übersicht

| Name | Thema | Letzte Nachricht von dir | Tage seit letzter Nachricht | Nachfassungen bisher | Empfehlung |
|---|---|---|---|---|---|
| Familie Lorenz (Anna) | Angebot Familien-Session | 26.10. | 7 (Frist 5, 2 Tage drüber) | 0 | Jetzt nachfassen |
| Tim Becker | Anfrage Paarshooting, deine Rückfrage (Datum, Ort) | 29.10. | 4 (Frist 3, 1 Tag drüber) | 0 | Jetzt nachfassen |
| Familie Roth | Angebot Fotobuch | 31.10. | 2 (Frist 5) | 0 | Noch warten, nachfassen ab Donnerstag, 5.11. |
| Sabine Koch | Angebot, abgesagt (zu teuer) | ? (Absage von ihr am 28.10.) | n. z. | n. z. | Nicht nachfassen |
| Paar Aydin/Schmidt | Hochzeitsangebot | 26.10. (zweite Nachfassung) | 7 (Frist 5, 2 Tage drüber) | 2 | Abschließen |

## Entwürfe

### Familie Lorenz (Anna)

Betreff: Dein Angebot für die Familien-Session

Hallo Anna,
ich wollte kurz nachfragen, ob mein Angebot für die Familien-Session vom 26.10. gut bei dir angekommen ist und ob noch Fragen offen sind. Magst du mir kurz sagen, ob das für euch passt? Und falls nicht, ist das völlig in Ordnung, dann sag es mir einfach ehrlich.

Liebe Grüße
Mara Eichhorn
Eichhorn Fotografie
0821 000000 | hallo@eichhorn-foto.example

### Tim Becker

Betreff: Dein Paarshooting: zwei kurze Fragen

Hallo Tim,
ich habe noch zwei Kleinigkeiten zu deiner Anfrage für das Paarshooting: Welches Datum schwebt dir vor, und wo soll es ungefähr stattfinden? Dann kann ich dir schnell sagen, ob es klappt. Falls sich das Thema erledigt hat, ist das auch völlig okay.

Liebe Grüße
Mara Eichhorn
Eichhorn Fotografie
0821 000000 | hallo@eichhorn-foto.example

### Paar Aydin/Schmidt (Abschlussnachricht)

Betreff: Euer Hochzeitsangebot

Hallo zusammen,
ich lege euer Hochzeitsangebot vom 12.10. erst mal ab, damit bei euch nichts offen bleibt. Falls ihr noch Fragen habt oder ein Vorgespräch möchtet, meldet euch gern jederzeit. Ich wünsche euch eine schöne Planung!

Liebe Grüße
Mara Eichhorn
Eichhorn Fotografie
0821 000000 | hallo@eichhorn-foto.example

## Hinweis für dich

- Den Kanal kenne ich nicht, deshalb stehen die Entwürfe als Mails mit Betreff da. Bei einer Kurznachricht entfällt der Betreff.
- Familie Roth: Die 5-Tage-Frist ist erst am Donnerstag, 5.11. erreicht. Dann gern noch einmal bei mir melden, ich schreibe den Entwurf.
- Sabine Koch: Hat abgesagt, deshalb kein Nachfassen. Wenn du möchtest, schreibe ich dir eine kurze, freundliche Dankesnachricht.
- Familie Lorenz: Wenn dein Angebot am 26.10. rausging, läuft es nach 14 Tagen am 9.11. ab. Im Entwurf habe ich das bewusst nicht erwähnt, damit kein Druck entsteht. Sag Bescheid, wenn du es drin haben möchtest.
- Aydin/Schmidt: Wenn das Angebot am 12.10. rausging, ist es seit dem 26.10. abgelaufen. Sollten sie sich doch noch melden, bräuchten sie ein neues Angebot, und bei Hochzeiten steht laut deinen Regeln zuerst ein Vorgespräch an. Deshalb habe ich es in der Abschlussnachricht angeboten. Ich kenne keine Namen und habe darum "Hallo zusammen" genommen.
- Annahmen: Bei Tim Becker gab es bisher keine Nachfassung, bei Lorenz und Roth ebenfalls nicht. Bei Koch kenne ich das Datum deiner letzten Nachricht nicht (`?`), es ist aber nicht nötig, weil sie abgesagt hat.

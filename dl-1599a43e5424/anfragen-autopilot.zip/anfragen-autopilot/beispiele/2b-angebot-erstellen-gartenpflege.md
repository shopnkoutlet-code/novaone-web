# Beispiel: Angebot erstellen

*Alle Personen, Firmen und Beträge sind erfunden. Geschäft: Gartenpflege (mit 19 % Umsatzsteuer).*

**Das wurde eingegeben:** "Angebot für Herrn Demir: Rasen mähen 300 m², Hecke schneiden 25 m, 2 Stunden Laub entfernen."

**So antwortet Claude mit dem Skill:**

---

Ich habe das Angebot KG-2026-012 für Herrn Ahmet Demir erstellt: Gesamtsumme 312,38 € brutto (262,50 € netto), gültig bis 02.12.2026. Eine Word-Datei kann ich hier nicht erzeugen. Du kannst den Text unten in ein eigenes Dokument kopieren.

---

**Keller Gartenpflege**
Jonas Keller
[Anschrift]
0731 000000 | info@keller-garten.example

Herr Ahmet Demir
Lindenstraße 17
89073 Ulm

**Angebot Nr. KG-2026-012**
Datum: 02.11.2026

Guten Tag Herr Demir,

vielen Dank für Ihre Anfrage. Gern biete ich Ihnen folgende Leistungen an:

| Pos. | Beschreibung | Menge | Einzelpreis (netto) | Gesamt (netto) |
|---|---|---|---|---|
| 1 | Rasenmähen, inkl. Randkanten und Entsorgung des Schnittguts | 300 m² | 0,15 € | 45,00 € |
| 2 | Heckenschnitt, inkl. Entsorgung | 25 lfd. m | 4,50 € | 112,50 € |
| 3 | Laubentfernung, inkl. Entsorgung | 2 Std. | 45,00 € | 90,00 € |
| 4 | Anfahrt, Pauschale | 1 | 15,00 € | 15,00 € |

| | |
|---|---|
| Summe netto | 262,50 € |
| Umsatzsteuer 19 % | 49,88 € |
| **Gesamtbetrag brutto** | **312,38 €** |

**Hinweise**
- Dieses Angebot ist gültig bis 02.12.2026 (30 Tage).
- Zahlungsziel: 14 Tage netto nach Rechnungserhalt. Eine Anzahlung ist nicht vorgesehen.
- Bankverbindung: Jonas Keller, IBAN DE02 1203 0000 0000 3030 62
- Annahmen: Die Laubentfernung ist mit 2 Stunden vor Ort angesetzt. Die Hecke ist nicht höher als 3 Meter. Der Einsatzort ist die Lindenstraße 17 in Ulm.
- Bei Dauerregen finden keine Termine statt. Der Termin wird dann verschoben.
- Rabatte sind nicht vorgesehen.

Über Ihren Auftrag freue ich mich. Einen Termin stimme ich gern mit Ihnen ab.

Freundliche Grüße

Jonas Keller
Keller Gartenpflege
0731 000000 | info@keller-garten.example

---

**Bitte prüfen**
- Anschrift: In mein-geschaeft.md steht deine Anschrift nicht. Im Kopf steht deshalb `[Anschrift]`.
- Anfahrt: Ich habe die Pauschale von 15,00 € netto (17,85 € brutto) angesetzt, weil der Einsatzort in Ulm liegt. Dabei habe ich angenommen, dass der Einsatzort die Kundenanschrift ist. Die Pauschale gilt einmal pro Einsatz. Wenn du für Rasen, Hecke und Laub an getrennten Terminen kommst, entscheidest du, ob sie mehrfach anfällt.
- Hecke: Die Höhe habe ich nicht abgefragt. Arbeiten über 3 Meter bietest du nicht an, daher die Annahme "bis 3 Meter".
- Laub: Die 2 Stunden sind die Angabe aus der Anfrage. Ob das reicht, weißt du besser.
- Sperrzeit: Ab Dezember machst du nur Laub und Winterschnitt. Das Angebot gilt bis 02.12.2026. Rasenmähen und Heckenschnitt müssten also im November stattfinden. Ein Termin steht noch nicht im Angebot.
- Mindestauftrag (60,00 €) ist erreicht.
- Rechenkontrolle: 45,00 + 112,50 + 90,00 + 15,00 = 262,50 €. 19 % davon sind 49,875 €, kaufmännisch gerundet 49,88 €. Brutto: 262,50 + 49,88 = 312,38 €.

**Begleitmail (Entwurf)**

Betreff: Ihr Angebot KG-2026-012

Guten Tag Herr Demir,

vielen Dank für Ihre Anfrage. Im Anhang finden Sie mein Angebot für Rasenmähen, Heckenschnitt und Laubentfernung. Gern stimme ich einen Termin mit Ihnen ab, wenn es für Sie passt.

Freundliche Grüße
Jonas Keller
Keller Gartenpflege
0731 000000 | info@keller-garten.example

Trage KG-2026-012 als letzte Nummer in mein-geschaeft.md ein.

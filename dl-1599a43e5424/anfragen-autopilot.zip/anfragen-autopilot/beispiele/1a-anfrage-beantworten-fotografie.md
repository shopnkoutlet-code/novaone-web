# Beispiel: Anfrage beantworten

*Alle Personen, Firmen und Beträge sind erfunden. Geschäft: Fotografin (duzt).*

**Das wurde eingegeben:** Instagram-Nachricht: "Hey, machst du auch Familienfotos? Wir sind zu viert, die Kinder sind 3 und 6. Was kostet das ungefähr? Lg Sandra"

**So antwortet Claude mit dem Skill:**

---

**Kurz verstanden:** Sandra fragt per Instagram nach Familienfotos für vier Personen (Kinder 3 und 6) und möchte wissen, was das ungefähr kostet.

**Entwurf:**

Hallo Sandra, ja, Familienfotos mache ich sehr gern! Eine Familien-Session dauert 60 Minuten draußen und kostet 190 € pauschal, inklusive 15 bearbeiteter Bilder digital. Der Preis gilt für die ganze Familie, ihr seid zu viert also kein Aufpreis. Weil es jetzt abends früh dunkel wird, fotografiere ich draußen am liebsten samstags vormittags. Magst du mir kurz sagen, wo ihr wohnt und ob ihr schon einen Wunschtermin im Kopf habt? Dann schaue ich, wann es bei mir passt. Liebe Grüße, Mara

**Hinweis für dich:**
- Ich habe vorgeschlagen, dass die Session samstags vormittags stattfindet, weil Mo bis Do ab 18 Uhr im November draußen schon dunkel ist. Streich den Satz, wenn du das anders sehen willst.
- Es steht noch kein konkreter Termin im Entwurf. Du musst ihn selbst bestätigen.
- Die Anfahrt (inklusive bis 20 km, danach 0,50 € pro km) habe ich nicht erwähnt. Ich habe nach dem Wohnort gefragt, damit du sie danach einrechnen kannst.

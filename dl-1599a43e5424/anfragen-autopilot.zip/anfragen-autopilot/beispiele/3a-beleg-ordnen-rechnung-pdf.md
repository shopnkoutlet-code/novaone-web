# Beispiel: Beleg ordnen

*Alle Personen, Firmen und Beträge sind erfunden. Geschäft: Fotografin.*

**Das wurde eingegeben:** Hochgeladenes PDF: Rechnung einer Druckerei (erfundene Firma). Frage: "Wann muss ich zahlen?"

**So antwortet Claude mit dem Skill:**

---

Eingangsrechnung der Druckerei Maier GmbH (Nr. 2026-0481 vom 08.10.2026): 142,80 € brutto, davon 22,80 € USt (19 %). Auf der Rechnung steht "Zahlbar innerhalb von 14 Tagen ohne Abzug". Das habe ich vom Rechnungsdatum aus berechnet: Fällig war sie am **22.10.2026**. Heute ist der 02.11.2026, die Rechnung ist also seit 11 Tagen überfällig.

Kategorie: Werbung (Flyer A5 und Visitenkarten). Dateiname: `2026-10-08_Druckerei-Maier_142-80`. Ablage: `Belege/2026/10`.

Du hast noch keine Übersicht angegeben, deshalb beginne ich eine neue.

| Datum | Aussteller | Nummer | Brutto | USt | Kategorie | Fällig bis | Status | Dateiname |
|---|---|---|---|---|---|---|---|---|
| 08.10.2026 | Druckerei Maier GmbH | 2026-0481 | 142,80 € | 22,80 € (19 %) | Werbung | 22.10.2026 (berechnet aus 14 Tagen), überfällig seit 11 Tagen | offen | 2026-10-08_Druckerei-Maier_142-80 |

**Zahlungsdaten, so wie sie auf der Rechnung stehen** (zum Kopieren):

- Empfänger: Druckerei Maier GmbH
- IBAN: `DE02 7205 0000 0000 1111 22`
- Verwendungszweck: `Rechnung 2026-0481`
- Betrag: `142,80 €`

Du überweist selbst. Ich zahle nichts und buche nichts.

**Zusammenfassung:** 1 Beleg, offen insgesamt 142,80 €, nächste Fälligkeit: 22.10.2026 (schon vorbei).

Soll ich die Übersicht als Excel- oder CSV-Datei anlegen?

# Beispiel: Wochenplan

*Alle Personen, Firmen und Beträge sind erfunden. Geschäft: Fotografin (Nebengewerbe, 10 Std/Woche).*

**Das wurde eingegeben:** Sieben Aufgaben, ein fester Termin am Mittwoch, Frist am Freitag.

**So antwortet Claude mit dem Skill:**

---

**Auf einen Blick:** Du hast diese Woche (Mo 2. bis Sa 7. November) höchstens 10 Stunden, nach 25 Prozent Puffer (2,5 Stunden) bleiben 7,5 Stunden, und die habe ich komplett verplant. Das Wichtigste: Hochzeit Aydin fertig bekommen (Frist Freitag, deshalb bis Donnerstag), das Angebot für Familie Lorenz und die Rechnung an Herrn Schulte raus. Vier Aufgaben passen nicht mehr in die Woche, die stehen unten mit Vorschlag.

**Plan:**

| Tag | Zeit/Block | Aufgabe | Dauer | Frist/Hinweis |
|---|---|---|---|---|
| Mo 2.11. | 18:00 bis 19:30 | Hochzeit Aydin: Bilder bearbeiten, Teil 1 | 1,5 Std | Frist Freitag 6.11. |
| Mo 2.11. | 19:30 bis 20:00 | Rechnung an Herrn Schulte schreiben | 30 Min (Schätzung) | keine Frist genannt, bringt Geld |
| Di 3.11. | 18:00 bis 18:45 | Angebot für Familie Lorenz schreiben | 45 Min (Schätzung) | Kunde wartet, endet vor dem Lauftreff |
| Di 3.11. | **19:00 Lauftreff** | privat, blockiert den Abend | | |
| Mi 4.11. | 18:00 bis 19:00 | Hochzeit Aydin: Bilder bearbeiten, Teil 2 | 1 Std | Frist Freitag 6.11. |
| Mi 4.11. | **19:00 bis 20:00 Vorgespräch Hochzeit** | Kundentermin | 1 Std (Schätzung) | Dauer nicht genannt, ich rechne eine Stunde |
| Do 5.11. | 18:00 bis 19:30 | Hochzeit Aydin: Bilder bearbeiten, Teil 3, danach in die Galerie | 1,5 Std | letzter Arbeitstag vor der Frist |
| Sa 7.11. | 9:00 bis 10:15 | Fotobuch Familie Roth gestalten, Teil 1 | 1 Std 15 Min | keine Frist genannt |

**So habe ich entschieden:**
- Hochzeit Aydin steht an erster Stelle, weil sie die einzige feste Frist hat. Freitag liegt außerhalb deiner Arbeitszeiten, deshalb plane ich sie so, dass sie Donnerstag fertig ist. Risiko: Donnerstag hat keine Reserve. Wird es dort knapp, hilft nur Freitagabend, den ich nicht eingeplant habe.
- Danach kommt, was Geld bringt oder wo ein Kunde wartet: Rechnung Schulte am Montag, Angebot Lorenz am Dienstag (innerhalb deiner 24 Stunden Antwortzeit). Dienstag ist nur eine Stunde frei, also passt das Angebot genau davor.
- Annahmen: Ich plane höchstens 2 Stunden pro Abend, weil in deiner Datei kein Ende steht. Für Samstag nehme ich 9 bis 13 Uhr als "vormittags" an und nutze nur den Anfang. Den Rest des Samstags und den Sonntag lasse ich frei. Die Zeiten für Rechnung, Angebot und Fotobuch sind Schätzungen. Das Fotobuch rechne ich mit ca. 2,5 Stunden gesamt.

**Passt diese Woche nicht:**
- **Fotobuch Roth, Rest (ca. 1 Std 15 Min):** Vorschlag: Di 10.11. ab 18:00, sofern bis dahin kein Termin dazukommt.
- **Belege vom Oktober sortieren (ca. 1,5 Std):** Vorschlag: Mo 9.11. 18:00 bis 19:30. Oder kleiner machen: diese Woche nur alle Belege in einen Ordner legen (ca. 15 Min), sortieren später.
- **Instagram-Beiträge für zwei Wochen planen (ca. 2 Std):** Vorschlag: Sa 14.11. vormittags als ein langer Block.
- **Neues Portfolio-Foto aussuchen (ca. 45 Min):** Vorschlag: Mi 11.11. 18:00 bis 18:45. Das kann warten.

Wenn du magst, schreibe ich dir den Plan als einfache Zeilen (Tag, Uhrzeit, Titel) zum Übertragen in deinen Kalender.

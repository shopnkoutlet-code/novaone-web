# Beispiel: Angebot erstellen

*Alle Personen, Firmen und Beträge sind erfunden. Geschäft: Fotografin (Kleinunternehmerin).*

**Das wurde eingegeben:** "Mach mir ein Angebot für Familie Lorenz: eine Familien-Session, dazu 10 zusätzliche bearbeitete Bilder. Shooting in Zusmarshausen, 32 km."

**So antwortet Claude mit dem Skill:**

---

Ich habe das Angebot A-2026-005 für Familie Lorenz (Frau Anna Lorenz) erstellt: Gesamtsumme 316,00 €, gültig bis 16.11.2026. Ich kann hier keine Word-Datei erzeugen. Kopiere den Text unten einfach in ein eigenes Dokument.

---

**Eichhorn Fotografie**
Mara Eichhorn
[Anschrift]
0821 000000 | hallo@eichhorn-foto.example

**An:**
Frau Anna Lorenz
Rosenweg 4
86199 Augsburg

**Angebot Nr. A-2026-005**
Datum: 02.11.2026
Gültig bis: 16.11.2026

Hallo Anna,

gern mache ich euch folgendes Angebot für eure Familien-Session in Zusmarshausen:

| Pos. | Beschreibung | Menge | Einzelpreis | Gesamt |
|---|---|---|---|---|
| 1 | Familien-Session: 60 Minuten draußen, 15 bearbeitete Bilder digital | 1 | 190,00 € | 190,00 € |
| 2 | Zusätzliches bearbeitetes Bild | 10 | 12,00 € | 120,00 € |
| 3 | Anfahrt Zusmarshausen: 32 km, davon 20 km inklusive, 12 km à 0,50 € | 12 km | 0,50 € | 6,00 € |
| | **Zwischensumme** | | | **316,00 €** |
| | **Gesamtsumme** | | | **316,00 €** |

Gemäß § 19 UStG wird keine Umsatzsteuer berechnet.

**Hinweise**
- Insgesamt erhaltet ihr 25 bearbeitete Bilder digital (15 aus der Session, 10 zusätzlich).
- Anfahrt: bis 20 km inklusive, danach 0,50 € pro km. Berechnet ist die einfache Strecke von 32 km.
- Das Angebot ist 14 Tage gültig, bis 16.11.2026.
- Zahlung: 14 Tage netto nach Rechnungsstellung. Eine Anzahlung ist nicht vorgesehen.
- Bankverbindung: Mara Eichhorn, IBAN DE02 1203 0000 0000 2020 51

Liebe Grüße
Mara Eichhorn
Eichhorn Fotografie
0821 000000 | hallo@eichhorn-foto.example

---

**Bitte prüfen**
- **Anschrift fehlt:** In deiner mein-geschaeft.md steht keine Anschrift. Im Kopf steht deshalb `[Anschrift]`. Bitte eintragen.
- **Anfahrt (Annahme):** In der Datei steht nicht, ob die 32 km einfach oder hin und zurück gelten. Ich habe die einfache Strecke gerechnet: 32 km minus 20 km inklusive = 12 km mal 0,50 € = 6,00 €. Bei Hin- und Rückfahrt (64 km, 20 km inklusive) wären es 44 km mal 0,50 € = 22,00 €. Das Angebot würde dann 332,00 € statt 316,00 € betragen.
- **Termin fehlt:** Es gibt kein Datum fürs Shooting. Beachte deinen Urlaub vom 21. bis 31. Dezember und dass Sonntag nicht geht.
- **Anrede (Annahme):** Ich habe geduzt, wie du es meistens machst. Du hast sie als "Frau Lorenz" genannt. Wenn sie dich gesiezt hat, bitte Anrede und Text anpassen.
- **Aus der Datei übernommen:** Kein Mindestauftrag und keine Anzahlung (die gilt nur bei Hochzeiten). Ich habe keinen Rabatt angesetzt. Region und Ort passen (Zusmarshausen liegt in Bayern, im 50-km-Umkreis).

**Begleitmail (Entwurf)**

Betreff: Dein Angebot für die Familien-Session

Hallo Anna,

super, dass ihr euch melden mögt! Im Anhang findest du das Angebot für eure Familien-Session in Zusmarshausen inklusive 10 zusätzlicher Bilder. Magst du mir kurz sagen, welcher Termin für euch passt?

Liebe Grüße
Mara

---

Trage A-2026-005 als letzte Nummer in mein-geschaeft.md ein.

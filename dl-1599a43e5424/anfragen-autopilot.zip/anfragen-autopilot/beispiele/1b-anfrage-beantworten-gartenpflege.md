# Beispiel: Anfrage beantworten

*Alle Personen, Firmen und Beträge sind erfunden. Geschäft: Gartenpflege (siezt).*

**Das wurde eingegeben:** Mail von Petra Lindner: Hecke ca. 40 m und Rasen ca. 250 m² in Neu-Ulm, "bitte verbindlich vorab"

**So antwortet Claude mit dem Skill:**

---

**Kurz verstanden:** Petra Lindner aus Neu-Ulm möchte eine zugewachsene Hecke (ca. 40 m) und einen Rasen (ca. 250 m²) in Ordnung bringen lassen, möglichst bald, und wünscht einen verbindlichen Preis vorab.

**Entwurf:**

Betreff: Ihre Anfrage zur Gartenarbeit

Guten Tag Frau Lindner,

Hecke und Rasen in Neu-Ulm übernehme ich gern. Nach Ihren Angaben ergibt sich dieser Preis:

- Heckenschnitt inkl. Entsorgung: 40 m x 4,50 € = 180,00 €
- Rasenmähen inkl. Randkanten und Entsorgung des Schnittguts: 250 m² x 0,15 € = 37,50 €
- Anfahrt (Pauschale): 15,00 €

Das sind 232,50 € netto, mit 19 % Umsatzsteuer 276,68 € brutto. Da die Maße noch Schätzwerte sind, kann ich den Preis erst nach den genauen Maßen verbindlich zusagen. Dafür genügt es, wenn Sie die Länge der Hecke und die Rasenfläche kurz nachmessen oder ich mir beides vor Ort ansehe.

Damit ich den Aufwand richtig einschätzen kann, hätte ich noch drei Fragen: Wie hoch ist die Hecke ungefähr (Arbeiten über 3 Metern kann ich nicht übernehmen)? Wie hoch steht der Rasen derzeit? Und gibt es einen direkten Zugang zum hinteren Garten, zum Beispiel ein Tor oder Seitenweg?

Einen Termin kann ich Ihnen voraussichtlich [TERMIN PRÜFEN] anbieten. Bitte beachten Sie, dass ein Termin bei Dauerregen witterungsbedingt verschoben wird.

Schicken Sie mir gern die Maße und Ihre Antworten, dann bestätige ich Ihnen den Preis.

Freundliche Grüße
Jonas Keller

Jonas Keller
Keller Gartenpflege
0731 000000 | info@keller-garten.example

**Hinweis für dich:**
- Der Preis ist eine Berechnung aus den Schätzwerten der Kundin. Ob du nach den genauen Maßen einen Festpreis zusagst, entscheidest du. Im Entwurf steht nur, dass er nach den genauen Maßen verbindlich wird.
- Marker: `[TERMIN PRÜFEN]`. Ich habe keinen Termin genannt. Wochentags ab 16:30 Uhr bis Sonnenuntergang ist es im November kaum noch hell genug; realistisch ist ein Samstag (zum Beispiel 7. oder 14. November). Trag dort ein, was du bestätigen kannst.
- Jahreszeit: Ab Dezember machst du nur Laub und Winterschnitt. Der Rasen sollte also noch im November erledigt werden, sonst müsstest du ihn absagen oder auf das Frühjahr verschieben.
- "Ziemlich zugewachsen" kann mehr Aufwand bedeuten als der Quadratmeter- und Meterpreis abdeckt. Ich habe keinen Zuschlag erfunden; deshalb die Fragen zu Höhe und Zustand.
- Kein Rabatt, auch wenn "Nachbarn beschweren sich" Druck aufbaut. Zum Thema Nachbarn habe ich nichts zugesagt.
- Mindestauftrag (60 €) ist erreicht. Antwortfrist: 2 Werktage (bis Mittwoch, 4. November).

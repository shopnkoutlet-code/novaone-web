# Beispiel: Beleg ordnen

*Alle Personen, Firmen und Beträge sind erfunden. Geschäft: Gartenpflege.*

**Das wurde eingegeben:** Hochgeladenes Foto eines Tankbelegs, Betrag verwischt (erfundener Beleg).

**So antwortet Claude mit dem Skill:**

---

Kassenbon der Stern-Tankstelle (Ulmer Str. 88, Neu-Ulm) vom 03.10.2026, 17:42 Uhr: 38,22 l Super E10 zu 1,659 €/l, mit Karte bezahlt. Der Gesamtbetrag und die MwSt sind auf dem Foto verwischt und nicht lesbar, deshalb steht dort `?`.

**Zwei kurze Fragen, dann trage ich es fertig ein:**

1. Was steht für diesen Tankvorgang auf dem Kontoauszug oder auf dem Original-Bon? Zur Kontrolle: 38,22 l × 1,659 €/l ergibt rechnerisch 63,41 €. Das ist nur eine Rechenprobe. In der Tabelle bleibt `?`, bis du den Betrag bestätigst.
2. Gehört dieser Beleg zum Geschäft? Eine Menge von 38 Litern ist mehr, als ich bei Rasenmäher-Sprit erwarten würde. Deshalb frage ich kurz nach, damit er richtig abgelegt wird (Keller Gartenpflege oder privat).

Die Übersicht ist neu, ich beginne sie mit diesem Beleg.

| Datum | Aussteller | Nummer | Brutto | USt | Kategorie | Fällig bis | Status | Dateiname |
|---|---|---|---|---|---|---|---|---|
| 03.10.2026 | Stern-Tankstelle | keine | ? | ? (19 %) | Kraftstoff | – | bezahlt | `2026-10-03_Stern-Tankstelle_XX` |

- **Art:** Kassenbon, schon bezahlt (Karte), keine Zahlung offen.
- **Kategorie:** Kraftstoff (aus deiner Liste), sofern der Beleg zum Geschäft gehört.
- **Ablage:** `Belege/2026/10`

**Zusammenfassung:** 1 Beleg, Summe der offenen Beträge 0,00 €, keine Fälligkeit.

Auf Wunsch erstelle ich dir die Übersicht auch als Excel- oder CSV-Datei.

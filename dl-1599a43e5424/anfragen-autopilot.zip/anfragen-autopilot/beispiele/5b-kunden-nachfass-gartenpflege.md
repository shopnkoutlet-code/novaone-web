# Beispiel: Kunden-Nachfass

*Alle Personen, Firmen und Beträge sind erfunden. Geschäft: Gartenpflege.*

**Das wurde eingegeben:** Vier offene Vorgänge (Angebot, Rückfrage, Nachfass ohne Echo, Angebot von heute).

**So antwortet Claude mit dem Skill:**

---

## Übersicht

Grundlage sind deine Regeln aus Abschnitt 7: Angebot 7 Tage, Rückfrage 3 Tage, höchstens 2 Nachfassungen. Stand ist heute, Montag, 2.11.2026.

| Name | Thema | Letzte Nachricht von dir | Tage seit letzter Nachricht | Nachfassungen bisher | Empfehlung |
|---|---|---|---|---|---|
| Herr Brandl | Angebot Laubentfernung | 20.10. | 13 (Frist seit 27.10. erreicht, 6 Tage drüber) | 0 | Jetzt nachfassen |
| Herr Weiß | Angebot | 21.10. (Nachfassung) | 12 (Frist seit 28.10. erreicht, 5 Tage drüber) | 1 | Jetzt nachfassen (zweite und letzte) |
| Frau Seidel | Rückfrage zur Heckenlänge (Heckenschnitt) | 30.10. | 3 (Frist heute erreicht) | 0 | Jetzt nachfassen |
| Herr Demir | Angebot | 2.11. (heute) | 0 | 0 | Noch warten, nachfassen ab 9.11. |

## Entwürfe

### Herr Brandl

**Betreff:** Ihr Angebot für die Laubentfernung

Guten Tag Herr Brandl,

ich wollte kurz nachfragen, ob mein Angebot für die Laubentfernung vom 20.10. bei Ihnen angekommen ist und ob noch Fragen offen sind. Gern vereinbare ich einen Termin, zum Beispiel am Samstag. Und falls es für Sie nicht passt, ist ein kurzes Nein völlig in Ordnung.

Freundliche Grüße
Jonas Keller

Jonas Keller
Keller Gartenpflege
0731 000000 | info@keller-garten.example

### Herr Weiß

**Betreff:** Noch Interesse an meinem Angebot?

Guten Tag Herr Weiß,

ich melde mich noch einmal zu meinem Angebot vom 14.10. Haben Sie sich dazu schon Gedanken gemacht, oder fehlt Ihnen noch eine Information von mir? Ein kurzes Ja oder Nein genügt, dann weiß ich, wie ich planen kann. Ein Nein ist völlig in Ordnung.

Freundliche Grüße
Jonas Keller

Jonas Keller
Keller Gartenpflege
0731 000000 | info@keller-garten.example

### Frau Seidel

**Betreff:** Ihre Anfrage zum Heckenschnitt

Guten Tag Frau Seidel,

für Ihre Anfrage zum Heckenschnitt bräuchte ich noch die ungefähre Länge der Hecke, dann kann ich Ihnen gern ein Angebot machen. Ein Schätzwert reicht völlig. Falls sich das Thema erledigt hat, geben Sie mir gern kurz Bescheid.

Freundliche Grüße
Jonas Keller

Jonas Keller
Keller Gartenpflege
0731 000000 | info@keller-garten.example

## Hinweis für dich

- Herr Demir: Das Angebot ging heute raus, also noch nichts tun. Nachfassen ab Montag, 9.11.
- Frau Seidel: Die Frist von 3 Tagen ist genau heute erreicht. Der Entwurf ist fällig, aber nicht überfällig.
- Herr Weiß: Das wäre die zweite und letzte Nachfassung. Kommt darauf keine Antwort und sind 7 Tage vergangen (ab 9.11.), wäre der nächste Schritt eine freundliche Abschlussnachricht.
- Gültigkeit: Das Angebot von Herrn Weiß läuft bei 30 Tagen am 13.11. ab, das von Herrn Brandl am 19.11. Ich habe es nicht in die Entwürfe geschrieben, weil es noch nicht drängt. Sag Bescheid, wenn es rein soll.
- Kanal: Ich kenne den Kanal nicht und habe Mails mit Betreff geschrieben. Bei WhatsApp oder SMS fällt der Betreff weg.

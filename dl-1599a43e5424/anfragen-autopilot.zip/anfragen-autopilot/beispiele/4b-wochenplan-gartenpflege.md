# Beispiel: Wochenplan

*Alle Personen, Firmen und Beträge sind erfunden. Geschäft: Gartenpflege (Nebengewerbe, 14 Std/Woche).*

**Das wurde eingegeben:** Sieben Aufgaben, Donnerstag Fußball, eine Kundin drängt.

**So antwortet Claude mit dem Skill:**

---

**Auf einen Blick:** Du hast diese Woche höchstens 14 Stunden, abzüglich 25 Prozent Puffer (3,5 Stunden) bleiben 10,5 planbar, ich plane 10 verbindlich. Deine Liste summiert sich auf 14 Stunden, das passt also nur ohne jeden Puffer, und die Laubarbeit bei Familie Brandl fällt deshalb raus. Die drei wichtigsten Dinge: Heckenschere schärfen lassen (Montag, sonst fehlt sie am Samstag), die drei Angebote und die Rechnung Seidel (bringen Geld) und die Hecke bei Frau Lindner am Samstag.

**Plan:**

| Tag | Zeit/Block | Aufgabe | Dauer | Frist/Hinweis |
|---|---|---|---|---|
| Mo 2.11. | 16:30 bis 17:15 | Heckenschere zum Schärfen bringen | 45 Min (Schätzung inkl. Abgabe) | Blockiert die Hecke am Samstag, daher zuerst |
| Mo 2.11. | 17:15 bis 18:15 | Drei Angebote schreiben (als ein Block) | 60 Min | keine Frist genannt |
| Di 3.11. | 16:30 bis 16:45 | Rechnung Herr Seidel | 15 Min | keine Frist genannt |
| Di 3.11. | 16:45 bis 17:45 | Winterplan Rasenmäher | 60 Min | keine Frist genannt |
| Mi 4.11. | frei | Puffer (Kundenfragen, Unvorhergesehenes) | | |
| **Do 5.11.** | **18:00 Fußball** | Davor nichts geplant | | Privat, blockiert die Zeit |
| Fr 6.11. | frei | Puffer | | Falls die Schere fertig ist, abholen (nicht eingerechnet) |
| Sa 7.11. | 8:00 bis 13:00 | Hecke Frau Lindner, Aufmaß und Schnitt | 5 Std (Schätzung von dir) | Sie drängt, Tageslicht nötig |
| Sa 7.11. | 13:30 bis 15:30 | Lager aufräumen | 2 Std | Tageslicht nicht nötig, gut als Abschluss |
| **So 8.11.** | **frei** | | | |

**So habe ich entschieden:**
- Reihenfolge: Schere zuerst (blockiert die Hecke), dann Geld und wartende Kunden (Angebote, Rechnung), dann die Hecke von Frau Lindner, weil sie drängt. Aufräumen und Winterplan ohne Frist kommen danach.
- Unter der Woche ist es ab ca. 16:50 dunkel (Sonnenuntergang geschätzt), Außenarbeit geht deshalb nur samstags (Tageslicht ca. 7:00 bis 16:40, geschätzt). Die Schreibtischblöcke abends habe ich nach Sonnenuntergang auf höchstens 2 Stunden pro Abend gelegt, das ist meine Annahme.
- Risiko: Ich weiß nicht, wie lange das Schärfen dauert. Ist die Schere am Samstag nicht zurück, verschiebt sich die Hecke. Die Abholung (ca. 30 Minuten) ist nicht eingerechnet, sie fällt in den Puffer.

**Passt diese Woche nicht:**
- Laub bei Familie Brandl (4 Std): Es braucht Tageslicht, und am Samstag ist mit der Hecke schon fast der ganze helle Tag voll. Vorschlag: Samstag 14.11., 8:00 bis 12:00. Wenn es für Brandl dringender ist als für Frau Lindner, sag Bescheid, dann tausche ich die beiden.
